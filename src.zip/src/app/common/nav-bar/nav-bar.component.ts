import { Component, OnInit } from '@angular/core';
import {CartService} from "../../services/cart.service";
import {AuthService} from "../../services/auth.service";

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {

  public numOfItemsAdded=0;
  public userLogin:boolean=false;
  constructor(private _CartService:CartService,private _AuthService:AuthService) {
    this.numOfItemsAdded=JSON.parse(localStorage.getItem('cartQ')!).length;
    localStorage.setItem('userLogin','false');
  }

  ngOnInit(): void {
    localStorage.setItem('userLogin','false');
  }
  itemsChanged(){
    this.numOfItemsAdded=JSON.parse(localStorage.getItem('cartQ')!).length;
  }

  checkLogin(){
    // this.userLogin= JSON.stringify(localStorage.getItem('userLogin'));
    // return (this.userLogin=="true");
  }
  // pressLogin() {
  //   // this._LoginService.setIsLogin();
  //   // this.userLogin=true;
  // }
}
