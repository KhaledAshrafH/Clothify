import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class ProductServiceService {

  constructor(private _HttpClient:HttpClient) { }
  getProducts():Observable<any>{
    return this._HttpClient.get("https://fakestoreapi.com/products");
  }

  getCategoryProducts(selectedCategory:string):Observable<any>{
    return this._HttpClient.get("https://fakestoreapi.com/products/category/"+selectedCategory);
  }

}
