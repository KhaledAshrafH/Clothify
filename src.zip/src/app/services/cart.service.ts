import { Injectable } from '@angular/core';
import {Product} from '../interfaces/product'
@Injectable({
  providedIn: 'root'
})
export class CartService {


  //OBJ From database , obj from user id (authservice)


  constructor() {

  }

}
