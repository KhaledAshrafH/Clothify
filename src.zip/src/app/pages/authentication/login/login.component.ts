import {Component, OnInit, TemplateRef, ViewChild} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from "@angular/forms";
import {AuthService} from "../../../services/auth.service";
import {Router} from "@angular/router";
import {AlertService} from "../../../services/alert.service";
import {User} from "../../../interfaces/user";
import {NavBarComponent} from "../../../common/nav-bar/nav-bar.component";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm:any=new FormGroup({
    email: new FormControl(),
    password: new FormControl()
  });

  isLogin=false;
  @ViewChild('invalidCredentials', {static: true}) invCredentials: TemplateRef<any> | undefined;
  authCredentialsDto: any;
  user:any;
  constructor(private authService: AuthService,
              private router: Router,
              private fb: FormBuilder,
              private alertService: AlertService,
              ) {
    if (this.authService.isLoggedIn()) {
      this.router.navigate(['/home']);
    }
  }

  ngOnInit(): void {

  }


  userLogin() {

    this.isLogin=true;
    localStorage.setItem('userLogin','false')
    console.log(this.loginForm.value);
    this.authService.login(this.loginForm.value).subscribe(
      res => {
        localStorage.setItem("token", res.token);
        this.authService.name=res.name;
        this.authService.email=res.email;
        this.isLogin=true;
        this.router.navigate([`/home`]);
      },
      error => {
        this.alertService.error(error);
        //this.openModal(this.invCredentials);
      }
    );
  }

  hide() {

  }
}
