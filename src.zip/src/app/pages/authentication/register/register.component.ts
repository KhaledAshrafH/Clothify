import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup, Validators} from "@angular/forms";

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  register: any=[];
  email:any=[]
  Submit(register: any){
    console.log("form is submitted", register)
  }
  regForm:any;
  registerForm:any=new FormGroup ({
    'name' : new FormControl ('', Validators.required),
    'username' : new FormControl ('', Validators.required),
    'email' : new FormControl ('', [Validators.required, Validators.email]), //2nd validator is to check whether it is an email or not
    'password' : new FormControl ('', [Validators.required, Validators.pattern('((?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,30})')]),
    'address' : new FormControl ('', [Validators.required, Validators.minLength(10)]),
    'mobilenumber' : new FormControl (20,[Validators.required,Validators.pattern('^01[0-2,5]{1}[0-9]{8}$')] )
  });
  constructor() { }

  ngOnInit(): void {

  }

  userRegister() {
    console.log(this.registerForm.value);
  }
}
