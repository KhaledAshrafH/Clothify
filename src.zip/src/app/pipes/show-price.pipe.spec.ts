import { ShowPricePipe } from './show-price.pipe';

describe('ShowPricePipe', () => {
  it('create an instance', () => {
    const pipe = new ShowPricePipe();
    expect(pipe).toBeTruthy();
  });
});
